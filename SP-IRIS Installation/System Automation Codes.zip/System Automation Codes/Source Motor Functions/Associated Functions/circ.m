function [out] = circ(r)

out = abs(r)<= 1;
end